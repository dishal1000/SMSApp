﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace NINASSMS
{
    public partial class LayawayPaymentDue : System.Web.UI.Page
    {
        public string apikey = ConfigurationManager.AppSettings["apikey"];
        public string sender = ConfigurationManager.AppSettings["sender"];
        public string secret = ConfigurationManager.AppSettings["secret"];
        public string url = ConfigurationManager.AppSettings["url"];
        public string FromNo = ConfigurationManager.AppSettings["FromNo"];
        DataAccess DA = new DataAccess();

        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnLayaway_Click(object sender, EventArgs e)
        {
            int result = DA.InsertContact(txtcode.Text.Trim() + txtcontact.Text, string.Empty);//5/2/2026: Prem Asked to same the contacts
            DataSet dsmessage = new DataSet();
            dsmessage = DA.getMessageList();
            if (dsmessage.Tables.Count > 0 && dsmessage.Tables[0].Rows.Count > 0)
            {
                for (int i = 0; i < dsmessage.Tables[0].Rows.Count; i++)
                {
                    if (dsmessage.Tables[0].Rows[i]["Status"].ToString() == "Layaway Pymnt Due")
                    {
                        SendSMS("", txtcode.Text.Trim() + txtcontact.Text.Trim(),  "Ninas Jewelry Layaway Ticket:" + txtJobID.Text.Trim() + "  " + dsmessage.Tables[0].Rows[i]["Message"].ToString().Trim());

                        lblMessage.Text = "Ninas Jewelry Layaway Ticket:" + txtJobID.Text.Trim() + "  " + dsmessage.Tables[0].Rows[i]["Message"].ToString().Trim();//5/2/2026: Prem Asked to show the sms message in label
                    }
                   
                }
            }

            //SendSMS("", txtcode.Text.ToString().Trim()+txtcontact.Text.ToString().Trim(), "Thank you for visiting Nina's Jewelry Store. Kindly leave us a review on Google https://txt.so/eoFFFp Questions? 954-722-8082.");
            txtcontact.Text = "";
            txtJobID.Text = string.Empty;
        }

        public string SendSMS(string src, string contactno, string msg)
        {
            //string apiUrl = "https://api-app2.simpletexting.com/v2/api/messages"; // API endpoint URL
            string phoneNumber = contactno; // Recipient's phone number
            string message = HttpUtility.UrlEncode(msg).Replace("+", " ").Replace("%3a", ":").Replace("%3f", "?").Replace("%27", "'").Replace("%2f", "/").Replace("%2c", ",").Replace("%23", "#").Replace("%c2%a0", " ").Replace("%0a", "\n").Replace("%0d", "\r"); // URL-encoded message
            message = message.Contains("%") ? msg : message;
            // Data to send in the SMS API request
            var smsData = new
            {
                contactPhone = phoneNumber, // Recipient's phone number
                accountPhone = FromNo,  // Dynamic account phone (replacing hardcoded value)
                mode = "AUTO", // Message mode
                text = message // Message content
            };

            using (HttpClient client = new HttpClient())
            {
                client.DefaultRequestHeaders.Add("Authorization", $"Bearer {apikey}"); // Add the authorization header with the API key

                // Serialize the data into JSON
                StringContent content = new StringContent(JsonConvert.SerializeObject(smsData), Encoding.UTF8, "application/json");

                try
                {
                    // Send the POST request to the API
                    HttpResponseMessage response = client.PostAsync(url, content).Result;

                    if (response.IsSuccessStatusCode)
                    {
                        // Parse the response if needed (currently logging success)
                        string responseContent = response.Content.ReadAsStringAsync().Result;

                        // Show a success alert to the user
                        ScriptManager.RegisterClientScriptBlock(Page, typeof(Page), "ClientScript", "alert('SMS sent successfully.')", true);
                    }
                    else
                    {
                        // Handle error response
                        string errorResponse = response.Content.ReadAsStringAsync().Result;

                        // Extract error details if available
                        string errorMessage = "Failed to send SMS.";
                        if (!string.IsNullOrEmpty(errorResponse))
                        {
                            try
                            {
                                var errorData = JsonConvert.DeserializeObject<dynamic>(errorResponse);
                                errorMessage = errorData?.error?.message ?? errorMessage;
                            }
                            catch
                            {
                                // Ignore JSON parsing errors
                            }
                        }

                        // Display the error message
                        ScriptManager.RegisterClientScriptBlock(Page, typeof(Page), "ClientScript", $"alert('{errorMessage}')", true);
                    }
                }
                catch (Exception ex)
                {
                    // Log the exception and notify the user
                    ScriptManager.RegisterClientScriptBlock(Page, typeof(Page), "ClientScript", "alert('Something went wrong while sending SMS.')", true);
                    Library.writeMessageLog($"Page:Default, Method:SendSMS - {ex}");
                }
            }

            return ""; // Return an empty string as per the original method's behavior
        }
    }
}