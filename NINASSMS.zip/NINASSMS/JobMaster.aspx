﻿<%@ Page Title="" Language="C#" MasterPageFile="~/Site.Master" AutoEventWireup="true" CodeBehind="JobMaster.aspx.cs" Inherits="NINASSMS.JobMaster" %>

<asp:Content ID="HeaderContent" runat="server" ContentPlaceHolderID="HeadContent">
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" />
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <style type="text/css">
        
    </style>
</asp:Content>
<asp:Content ID="BodyContent" runat="server" ContentPlaceHolderID="MainContent">
    <div class="jumbotron">
        <div class="below-slideshow" style="padding-bottom: 0px">
            <div class="container">
                <!-- Page Header -->
                <h2 class="text-center font-weight-bold text-primary">Job List</h2>
                <hr />
                <!-- NOTICE HERE:inside div declare class as container/container-fluid-->
                <div class="row">
                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                        <div>
                            <div>
                                <div class="row pb-4">
                                    <div class="col-md-3 col-sm-12 pl-0 pt-2">
                                        <asp:DropDownList ID="DropDownList1" CssClass="form-control" runat="server">
                                            <asp:ListItem Text="Name" Value="Name" Selected="True" />
                                            <asp:ListItem Text="Job number" Value="JobID" />
                                            <asp:ListItem Text="Status" Value="Status" />
                                            <asp:ListItem Text="Contact number" Value="ContactNo" />
                                        </asp:DropDownList>
                                    </div>

                                    <div class="col-md-4 col-sm-12 pl-0 pt-2">
                                        <div class="row">
                                            <div class="col-md-9 col-sm-10 col-10 pr-1">
                                                <asp:TextBox ID="txtSearch" CssClass="form-control" runat="server"></asp:TextBox>
                                            </div>
                                            <div class="col-md-3 col-sm-2 col-2 pl-0 pt-1">

                                                <asp:Button ID="btnSearch" CssClass="btn btn-sm btn-primary" runat="server" OnClick="Search" Text="Search" />
                                            </div>
                                        </div>
                                    </div>

                                    <div class="col-md-5 col-sm-12 pl-0 pt-2">
                                        <div class="row">
                                            <div class="col-md-9 col-9 col-sm-9">

                                                <asp:TextBox ID="txtmsg" runat="server" CssClass="form-control" MaxLength="140" TextMode="MultiLine"></asp:TextBox>
                                            </div>
                                            <div class="col-md-3 col-3 col-sm-3 pl-0 pt-1">

                                                <asp:Button ID="Button1" runat="server" CssClass="btn btn-sm btn-primary" Text="Send SMS"
                                                    OnClick="Button1_Click" />
                                            </div>
                                        </div>
                                    </div>

                                </div>

                                <div class="row">
                                    <div class="col-12">
                                        <asp:GridView ID="GridView1" runat="server" CssClass="table table-responsive-sm table-striped table-hover table-bordered" AutoGenerateColumns="false" AllowPaging="true"
                                            AllowSorting="true" OnSorting="OnSorting" OnPageIndexChanging="OnPageIndexChanging"
                                            PageSize="30" OnRowCommand="GridView1_RowCommand">
                                            <Columns>
                                                <asp:TemplateField>
                                                    <ItemTemplate>
                                                        <asp:CheckBox ID="chkRow" runat="server" />
                                                    </ItemTemplate>
                                                </asp:TemplateField>
                                                <asp:BoundField DataField="Name" HeaderText="Name" ItemStyle-Width="150" SortExpression="Name" />
                                                <asp:BoundField DataField="ContactNo" HeaderText="Contact number" ItemStyle-Width="150" SortExpression="ContactNo" />
                                                <asp:BoundField DataField="JobID" HeaderText="Job number" ItemStyle-Width="150" SortExpression="JobID" />
                                                <asp:BoundField DataField="Status" HeaderText="Status" ItemStyle-Width="150" SortExpression="Status" />
                                                <asp:BoundField DataField="Note" HeaderText="Note" ItemStyle-Width="150" SortExpression="Note" />
                                                <asp:TemplateField>
                                                    <ItemTemplate>
                                                        <asp:LinkButton ID="LinkButton1" Text="Select" runat="server" CommandName="Select" CommandArgument='<%# Eval("Id") %>' />
                                                    </ItemTemplate>
                                                </asp:TemplateField>
                                            </Columns>
                                        </asp:GridView>

                                    </div>
                                </div>
                                <br />
                                <%--<asp:Button ID="btnGetSelected" runat="server" Text="Get selected records" OnClick="GetSelectedRecords" />
<hr />
<u>Selected Rows</u>
<br />
<asp:GridView ID="gvSelected" runat="server" HeaderStyle-BackColor="#3AC0F2" HeaderStyle-ForeColor="White"
    AutoGenerateColumns="false">
    <Columns>
        <asp:BoundField DataField="Name" HeaderText="Name" ItemStyle-Width="150" />
        <asp:BoundField DataField="Country" HeaderText="Country" ItemStyle-Width="150" />
    </Columns>
</asp:GridView>--%>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</asp:Content>
