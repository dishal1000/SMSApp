﻿using System.Configuration;
using System.Data.SqlClient;
using System.Data;
using System;
using System.Xml.Linq;
using System.Web.Services.Description;

namespace NINASSMS
{
    internal class DataAccess
    {
        SqlConnection _SqlConnection;
        SqlCommand _SqlCommand;
        SqlDataAdapter _SqlDataAdapter;

        public static string _ConnectionString = ConfigurationManager.AppSettings["Connectionstring"];

        public int InsertContact(string contactnumber, string Name)
        {
            int Updated = 0;
            _SqlConnection = new SqlConnection();
            _SqlConnection.ConnectionString = _ConnectionString;
            try
            {

                _SqlCommand = new SqlCommand();
                _SqlCommand.Connection = _SqlConnection;
                _SqlCommand.CommandType = System.Data.CommandType.StoredProcedure;
                _SqlCommand.CommandText = "SP_InsertContactMaster";
                _SqlCommand.Parameters.Add(new SqlParameter("@ContactNo", contactnumber));
                _SqlCommand.Parameters.Add(new SqlParameter("@Name", Name));

                if (_SqlConnection.State == System.Data.ConnectionState.Closed)
                {
                    _SqlConnection.Open();
                    _SqlDataAdapter = new SqlDataAdapter(_SqlCommand);
                    Updated = Convert.ToInt32(_SqlCommand.ExecuteScalar());
                }
            }
            catch (Exception ex)
            {
                Library.writeMessageLog("Method:Insertcontact" + ex.ToString());
                Updated = -1;
            }
            finally
            {
                if (_SqlConnection.State == System.Data.ConnectionState.Open)
                {
                    _SqlConnection.Close();
                }
            }
            return Updated;
        }
        public DataSet getcontactdata(string contactnumber)
        {
            DataSet _dtsTransaction = new DataSet();
            int Updated = 0;
            _SqlConnection = new SqlConnection();
            _SqlConnection.ConnectionString = _ConnectionString;
            try
            {

                _SqlCommand = new SqlCommand();
                _SqlCommand.Connection = _SqlConnection;
                _SqlCommand.CommandType = System.Data.CommandType.StoredProcedure;
                _SqlCommand.CommandText = "SP_SearchConatct";
                _SqlCommand.Parameters.Add(new SqlParameter("@contactnumber", contactnumber));
                if (_SqlConnection.State == System.Data.ConnectionState.Closed)
                {
                    _SqlConnection.Open();
                    _SqlDataAdapter = new SqlDataAdapter(_SqlCommand);
                    _SqlDataAdapter.Fill(_dtsTransaction);
                }
            }
            catch (Exception ex)
            {
                Library.writeMessageLog("Method:getcontactdata" + ex.ToString());
                Updated = -1;
            }
            finally
            {
                if (_SqlConnection.State == System.Data.ConnectionState.Open)
                {
                    _SqlConnection.Close();
                }
            }
            return _dtsTransaction;
        }

        public DataSet getMessageList()
        {
            DataSet _dtsTransaction = new DataSet();
            int Updated = 0;
            _SqlConnection = new SqlConnection();
            _SqlConnection.ConnectionString = _ConnectionString;
            try
            {

                _SqlCommand = new SqlCommand();
                _SqlCommand.Connection = _SqlConnection;
                _SqlCommand.CommandType = System.Data.CommandType.StoredProcedure;
                _SqlCommand.CommandText = "SP_Message";

                if (_SqlConnection.State == System.Data.ConnectionState.Closed)
                {
                    _SqlConnection.Open();
                    _SqlDataAdapter = new SqlDataAdapter(_SqlCommand);
                    _SqlDataAdapter.Fill(_dtsTransaction);
                }
            }
            catch (Exception ex)
            {
                Library.writeMessageLog("Method:getmessagelist" + ex.ToString());
                Updated = -1;
            }
            finally
            {
                if (_SqlConnection.State == System.Data.ConnectionState.Open)
                {
                    _SqlConnection.Close();
                }
            }
            return _dtsTransaction;
        }

        public DataSet getJobdatabyContact(int contactnumber, int jobid)
        {
            DataSet _dtsTransaction = new DataSet();
            int Updated = 0;
            _SqlConnection = new SqlConnection();
            _SqlConnection.ConnectionString = _ConnectionString;
            try
            {

                _SqlCommand = new SqlCommand();
                _SqlCommand.Connection = _SqlConnection;
                _SqlCommand.CommandType = System.Data.CommandType.StoredProcedure;
                _SqlCommand.CommandText = "SP_JobMasterbyJob";
                if (contactnumber != 0)
                {
                    _SqlCommand.Parameters.Add(new SqlParameter("@ContactId", contactnumber));
                }
                if (jobid != 0)
                {
                    _SqlCommand.Parameters.Add(new SqlParameter("@JobID", jobid));
                }
                if (_SqlConnection.State == System.Data.ConnectionState.Closed)
                {
                    _SqlConnection.Open();
                    _SqlDataAdapter = new SqlDataAdapter(_SqlCommand);
                    _SqlDataAdapter.Fill(_dtsTransaction);
                }
            }
            catch (Exception ex)
            {
                Library.writeMessageLog("Method:getJobdata" + ex.ToString());
                Updated = -1;
            }
            finally
            {
                if (_SqlConnection.State == System.Data.ConnectionState.Open)
                {
                    _SqlConnection.Close();
                }
            }
            return _dtsTransaction;
        }
        public DataSet getJobdata(int contactnumber)
        {
            DataSet _dtsTransaction = new DataSet();
            int Updated = 0;
            _SqlConnection = new SqlConnection();
            _SqlConnection.ConnectionString = _ConnectionString;
            try
            {

                _SqlCommand = new SqlCommand();
                _SqlCommand.Connection = _SqlConnection;
                _SqlCommand.CommandType = System.Data.CommandType.StoredProcedure;
                _SqlCommand.CommandText = "SP_JobMaster";
                if (contactnumber != 0)
                {
                    _SqlCommand.Parameters.Add(new SqlParameter("@ContactID", contactnumber));
                }
                if (_SqlConnection.State == System.Data.ConnectionState.Closed)
                {
                    _SqlConnection.Open();
                    _SqlDataAdapter = new SqlDataAdapter(_SqlCommand);
                    _SqlDataAdapter.Fill(_dtsTransaction);
                }
            }
            catch (Exception ex)
            {
                Library.writeMessageLog("Method:getJobdata" + ex.ToString());
                Updated = -1;
            }
            finally
            {
                if (_SqlConnection.State == System.Data.ConnectionState.Open)
                {
                    _SqlConnection.Close();
                }
            }
            return _dtsTransaction;
        }
        public DataSet getMessage()
        {
            DataSet _dtsTransaction = new DataSet();
            int Updated = 0;
            _SqlConnection = new SqlConnection();
            _SqlConnection.ConnectionString = _ConnectionString;
            try
            {

                _SqlCommand = new SqlCommand();
                _SqlCommand.Connection = _SqlConnection;
                _SqlCommand.CommandType = System.Data.CommandType.StoredProcedure;
                _SqlCommand.CommandText = "SP_Message";
                
                if (_SqlConnection.State == System.Data.ConnectionState.Closed)
                {
                    _SqlConnection.Open();
                    _SqlDataAdapter = new SqlDataAdapter(_SqlCommand);
                    _SqlDataAdapter.Fill(_dtsTransaction);
                }
            }
            catch (Exception ex)
            {
                Library.writeMessageLog("Method:getJobdata" + ex.ToString());
                Updated = -1;
            }
            finally
            {
                if (_SqlConnection.State == System.Data.ConnectionState.Open)
                {
                    _SqlConnection.Close();
                }
            }
            return _dtsTransaction;
        }
        public int InsertJob(int Jobid, int contactIno, string Jobnumber, string Notes, string status, string CreatedBy, string repairtype, string type, string qty)
        {
            int Updated = 0;
            _SqlConnection = new SqlConnection();
            _SqlConnection.ConnectionString = _ConnectionString;
            try
            {

                _SqlCommand = new SqlCommand();
                _SqlCommand.Connection = _SqlConnection;
                _SqlCommand.CommandType = System.Data.CommandType.StoredProcedure;
                _SqlCommand.CommandText = "SP_InsertJob";
                _SqlCommand.Parameters.Add(new SqlParameter("@id", Jobid));
                _SqlCommand.Parameters.Add(new SqlParameter("@ContactId", contactIno));
                _SqlCommand.Parameters.Add(new SqlParameter("@JobID", Jobnumber));
                _SqlCommand.Parameters.Add(new SqlParameter("@Note", Notes));
                _SqlCommand.Parameters.Add(new SqlParameter("@Status", status));
                _SqlCommand.Parameters.Add(new SqlParameter("@Createdby", CreatedBy));
                _SqlCommand.Parameters.Add(new SqlParameter("@RepairType", repairtype));
                _SqlCommand.Parameters.Add(new SqlParameter("@Type", type));
                _SqlCommand.Parameters.Add(new SqlParameter("@Qty", qty));
                if (_SqlConnection.State == System.Data.ConnectionState.Closed)
                {
                    _SqlConnection.Open();
                    _SqlDataAdapter = new SqlDataAdapter(_SqlCommand);
                    Updated = _SqlCommand.ExecuteNonQuery();
                }
            }
            catch (Exception ex)
            {
                Library.writeMessageLog("Method:InsertJob" + ex.ToString());
                Updated = -1;
            }
            finally
            {
                if (_SqlConnection.State == System.Data.ConnectionState.Open)
                {
                    _SqlConnection.Close();
                }
            }
            return Updated;
        }

        internal int InsertMessage(string id, string message)
        {
            int Updated = 0;
            _SqlConnection = new SqlConnection();
            _SqlConnection.ConnectionString = _ConnectionString;
            try
            {

                _SqlCommand = new SqlCommand();
                _SqlCommand.Connection = _SqlConnection;
                _SqlCommand.CommandType = System.Data.CommandType.StoredProcedure;
                _SqlCommand.CommandText = "SP_InserMessage";
                _SqlCommand.Parameters.Add(new SqlParameter("@Status", id));
                _SqlCommand.Parameters.Add(new SqlParameter("@Message", message));

                if (_SqlConnection.State == System.Data.ConnectionState.Closed)
                {
                    _SqlConnection.Open();
                    _SqlDataAdapter = new SqlDataAdapter(_SqlCommand);
                    Updated = Convert.ToInt32(_SqlCommand.ExecuteScalar());
                }
            }
            catch (Exception ex)
            {
                Library.writeMessageLog("Method:InsertMessage" + ex.ToString());
                Updated = -1;
            }
            finally
            {
                if (_SqlConnection.State == System.Data.ConnectionState.Open)
                {
                    _SqlConnection.Close();
                }
            }
            return Updated;
        }
    }
}