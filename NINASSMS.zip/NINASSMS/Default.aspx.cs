﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Newtonsoft.Json;
using System.Net.Http;
using System.Text;
using System.Web.UI.WebControls.WebParts;

namespace NINASSMS
{
    public partial class _Default : Page
    {
        public string apikey = ConfigurationManager.AppSettings["apikey"];
        public string sender = ConfigurationManager.AppSettings["sender"];
        public string secret = ConfigurationManager.AppSettings["secret"];
        public string url = ConfigurationManager.AppSettings["url"];
        public string FromNo = ConfigurationManager.AppSettings["FromNo"];

        private string SortDirection
        {
            get { return ViewState["SortDirection"] != null ? ViewState["SortDirection"].ToString() : "ASC"; }
            set { ViewState["SortDirection"] = value; }
        }
        protected void Page_Load(object sender, EventArgs e)
        {
            string contact = "";
            string jobid = "";
            if (!IsPostBack)
            {
                fillstatus();
                contact = Convert.ToString(Session["contactno"]);
                jobid = Convert.ToString(Session["jobid"]);
                if (contact != "")
                {
                    txtcontact.Text = contact.Substring(1, contact.Length - 1);
                    if (txtcontact.Text.Trim() != "")
                    {
                        Search();
                        SearchbyJob(jobid);
                    }
                }
                this.BindGrid();
            }
            else
            {

            }
        }
        protected void txtcontact_TextChanged(object sender, EventArgs e)
        {
            //Search();
        }
        protected void btnsave_Click(object sender, EventArgs e)
        {
            int result = 0;
            DataAccess DA = new DataAccess();
            DataSet dsmessage = new DataSet();
            result = DA.InsertContact(txtcode.Text.Trim() + txtcontact.Text, txtName.Text);
            //Search();
            try
            {
                // Updated: Added input validation for contact number
                if (txtcontact.Text.Trim() == "" || !txtcontact.Text.Trim().All(char.IsDigit))
                {
                    ScriptManager.RegisterClientScriptBlock(Page, typeof(Page), "ClientScript", "alert('Please enter a valid contact number.')", true);
                    return;
                }
                dsmessage = DA.getMessageList();
                if (HF1.Value == "")
                {
                    HF1.Value = result.ToString();
                }
                if (HFSTATUS.Value == "")
                {
                    HFSTATUS.Value = "Received";
                }

                if (HFSTATUS.Value == "Marketing")
                {

                }
                else
                {
                    string Repairtype = "";
                    if (rbjewellery.Checked)
                    {
                        Repairtype = "Jewelry";
                    }
                    else if (rbwatch.Checked)
                    {
                        Repairtype = "Watch";
                    }
                    string type = "";
                    if (rbdrop.Checked)
                    {
                        type = "Drop";
                    }
                    else if (rbwait.Checked)
                    {
                        type = "Wait";
                    }
                    result = DA.InsertJob(Convert.ToInt32(HFJOB.Value == "" ? "0" : HFJOB.Value), Convert.ToInt32(HF1.Value == "" ? "0" : HF1.Value), txtjobnumber.Text.Trim(), txtNote.Text.Trim(), HFSTATUS.Value, "", Repairtype, type, ddlqty.Text);
                    if (dsmessage.Tables.Count > 0 && dsmessage.Tables[0].Rows.Count > 0)
                    {
                        if (HFSTATUS.Value != "Marketing" && HFSTATUS.Value != "Completed")
                        {
                            for (int i = 0; i < dsmessage.Tables[0].Rows.Count; i++)
                            {
                                
                                if (dsmessage.Tables[0].Rows[i]["Status"].ToString() == HFSTATUS.Value)
                                {
                                   /*
                                    if (dsmessage.Tables[0].Rows[i]["Status"].ToString() == "Layaway Pymnt Due" || dsmessage.Tables[0].Rows[i]["Status"].ToString() == "Layaway Past Due")
                                    {
                                        sendSMS(txtcode.Text.Trim() + txtcontact.Text.Trim(), "", "Ninas Jewelry Layaway Ticket:" + txtjobnumber.Text.Trim() + "  " + dsmessage.Tables[0].Rows[i]["Message"].ToString().Trim());
                                    }
                                    else
                                    {
                                        sendSMS(txtcode.Text.Trim() + txtcontact.Text.Trim(), "", "Ninas Jewelry Ticket:" + txtjobnumber.Text.Trim() + " your " + Repairtype.ToString().Trim() + " repair order for " + ddlqty.Text + "  " + dsmessage.Tables[0].Rows[i]["Message"].ToString().Trim());
                                    }

                                    /* 01/15/2025: changes the message structure and added new status Pick Past Due*/
                                    if (dsmessage.Tables[0].Rows[i]["Status"].ToString() == "Layaway Pymnt Due" || dsmessage.Tables[0].Rows[i]["Status"].ToString() == "Layaway Past Due")
                                    {
                                        sendSMS(txtcode.Text.Trim() + txtcontact.Text.Trim(), "", "Ninas Jewelry Layaway Ticket:" + txtjobnumber.Text.Trim() + "  " + dsmessage.Tables[0].Rows[i]["Message"].ToString().Trim());
                                    }
                                    else if(dsmessage.Tables[0].Rows[i]["Status"].ToString()== "Pickup Past Due")
                                    {
                                        sendSMS(txtcode.Text.Trim() + txtcontact.Text.Trim(), "", "Ninas Jewelry-Final Reminder to pickup Repair Ticket#" + txtjobnumber.Text.Trim() + ". " + dsmessage.Tables[0].Rows[i]["Message"].ToString().Trim());
                                    }
                                    else if (dsmessage.Tables[0].Rows[i]["Status"].ToString() == "Exception")//Ticket Exception Add the note field at end of the message.
                                    {
                                        sendSMS(
                                                txtcode.Text.Trim() + txtcontact.Text.Trim(),
                                                "",
                                                "Ninas Jewelry" + Environment.NewLine + // Newline after "Ninas Jewelry"
                                                "Your Jewelry/Watch Repair Ticket#" + txtjobnumber.Text.Trim() + " " +
                                                txtNote.Text.Trim()+
                                                " " + dsmessage.Tables[0].Rows[i]["Message"].ToString().Trim() );
                                    }
                                    else
                                    {
                                        sendSMS(
                                                txtcode.Text.Trim() + txtcontact.Text.Trim(),
                                                "",
                                                "Ninas Jewelry" +Environment.NewLine+ // Newline after "Ninas Jewelry"
                                                "Your Jewelry/Watch Repair Ticket#" + txtjobnumber.Text.Trim() +
                                                " " + dsmessage.Tables[0].Rows[i]["Message"].ToString().Trim());
                                    }

                                }
                            }
                        }
                        else
                        {
                            for (int i = 0; i < dsmessage.Tables[0].Rows.Count; i++)
                            {
                                if (dsmessage.Tables[0].Rows[i]["Status"].ToString() == HFSTATUS.Value)
                                {
                                    sendSMS(txtcode.Text.Trim() + txtcontact.Text.Trim(), "", dsmessage.Tables[0].Rows[i]["Message"].ToString().Trim());
                                }
                            }
                        }
                    }
                    clear();
                    //MessageBox.Show("Contact Saved");
                    ScriptManager.RegisterClientScriptBlock(Page, typeof(Page), "ClientScript", "alert('Contact Saved')", true);
                }
            }
            catch (Exception ex)
            {
                Library.writeMessageLog("Page:Default,Method:btnsave_Click" + ex.ToString());
                ScriptManager.RegisterClientScriptBlock(Page, typeof(Page), "ClientScript", "alert('An error occurred while saving the contact.')", true);
            }
        }
        protected void fillstatus()
        {
            ddlstatus.Items.Insert(0, new ListItem("Received", "Received"));
            ddlstatus.Items.Insert(1, new ListItem("Pickup", "Pickup"));
            ddlstatus.Items.Insert(2, new ListItem("Completed", "Completed"));
            ddlstatus.Items.Insert(3, new ListItem("Exception", "Exception"));
            ddlstatus.Items.Insert(4, new ListItem("Marketing", "Marketing"));
            ddlstatus.Items.Insert(5, new ListItem("Layaway Payment Due", "Layaway Pymnt Due"));
            ddlstatus.Items.Insert(6, new ListItem("Layaway Past Due", "Layaway Past Due"));
            ddlstatus.Items.Insert(7, new ListItem("Pickup Past Due", "Pickup Past Due"));  /*01/15/2025 Added the new status Pick Past Due*/
        }
        /**
        public string sendSMS(string contactno, string src, string msg)
        {
            String message = HttpUtility.UrlEncode(msg);
            string result = "";
            using (var wb = new WebClient())
            {
                string key = apikey;
                string secretkey = secret;
                string URL = url;
                string to = contactno;
                string messages = msg;

                string sURL;


                sURL = URL + key + "&api_secret=" + secretkey + "&to=" + to + "&text=" + messages;

                try
                {

                    using (WebClient client = new WebClient())
                    {
                        client.Encoding = System.Text.Encoding.UTF8;

                        var s = client.DownloadString(sURL);
                        string ErrorMessage = "";
                        int status = 0;
                        string[] resp = s.Split(',');
                        if (resp.Length > 0)
                        {
                            if (resp[3].ToString() != "")
                            {
                                //resp[3]=resp[3].Replace(":","");
                                string[] errormsg = resp[3].Split(':');
                                if (errormsg.Length > 0)
                                {
                                    ErrorMessage = errormsg[1].ToString();
                                }
                            }
                            if (resp[4].ToString() != "")
                            {
                                resp[3] = resp[4].Replace(":", "");
                                string[] Statusmsg = resp[4].Split(':');
                                if (Statusmsg.Length > 0)
                                {
                                    status = Convert.ToInt32(Statusmsg[1].ToString().Replace("}", ""));
                                }
                            }
                        }
                        if (status != 0)
                        {
                            //MessageBox.Show(ErrorMessage);
                            ScriptManager.RegisterClientScriptBlock(Page, typeof(Page), "ClientScript", "alert(" + ErrorMessage + ")", true);
                        }
                        else
                        {
                            ScriptManager.RegisterClientScriptBlock(Page, typeof(Page), "ClientScript", "alert('SMS sent.')", true);
                        }

                    }
                }
                catch (Exception ex)
                {
                    ScriptManager.RegisterClientScriptBlock(Page, typeof(Page), "ClientScript", "alert('Something went wrong while sending sms.')", true);
                    Library.writeMessageLog("Page:Default,Method:SendSMS " + ex.ToString());
                    //ex.ToString();
                }
            }
            return "";

            //var client = new RestClient("https://www.thetexting.com/rest/sms/json/message/send");

            //var request = new RestRequest(Method.POST);
            //request.AddHeader("content-type", "application/x-www-form-urlencoded");
            //request.AddHeader("cache-control", "no-cache");    
            //request.AddParameter("application/x-www-form-urlencoded", "api_secret=ufzqu6uqtbwp9c9&api_key=ufzqu6uqtbwp9c9&from=19543140809&to=19549074441&text=Sample%20Message%20Text&type=text", ParameterType.RequestBody);

            //IRestResponse response = client.Execute(request);
        }
        **/
        public string sendSMS(string contactno, string src, string msg)
        {
            //string apiUrl = "https://api-app2.simpletexting.com/v2/api/messages"; // API endpoint URL
            string phoneNumber = contactno; // Recipient's phone number
            string message = HttpUtility.UrlEncode(msg).Replace("+", " ").Replace("%3a", ":").Replace("%3f", "?").Replace("%27", "'").Replace("%2f","/").Replace("%2c", ",").Replace("%23","#").Replace("%c2%a0"," ").Replace("%0a", "\n").Replace("%0d","\r"); // URL-encoded message

            // Data to send in the SMS API request
            var smsData = new
            {
                contactPhone = phoneNumber, // Recipient's phone number
                accountPhone = FromNo,  // Dynamic account phone (replacing hardcoded value)
                mode = "AUTO", // Message mode
                text = message // Message content
            };

            using (HttpClient client = new HttpClient())
            {
                client.DefaultRequestHeaders.Add("Authorization", $"Bearer {apikey}"); // Add the authorization header with the API key

                // Serialize the data into JSON
                StringContent content = new StringContent(JsonConvert.SerializeObject(smsData), Encoding.UTF8, "application/json");

                try
                {
                    // Send the POST request to the API
                    HttpResponseMessage response = client.PostAsync(url, content).Result;

                    if (response.IsSuccessStatusCode)
                    {
                        // Parse the response if needed (currently logging success)
                        string responseContent = response.Content.ReadAsStringAsync().Result;

                        // Show a success alert to the user
                        ScriptManager.RegisterClientScriptBlock(Page, typeof(Page), "ClientScript", "alert('SMS sent successfully.')", true);
                    }
                    else
                    {
                        // Handle error response
                        string errorResponse = response.Content.ReadAsStringAsync().Result;

                        // Extract error details if available
                        string errorMessage = "Failed to send SMS.";
                        if (!string.IsNullOrEmpty(errorResponse))
                        {
                            try
                            {
                                var errorData = JsonConvert.DeserializeObject<dynamic>(errorResponse);
                                errorMessage = errorData?.error?.message ?? errorMessage;
                            }
                            catch
                            {
                                // Ignore JSON parsing errors
                            }
                        }

                        // Display the error message
                        ScriptManager.RegisterClientScriptBlock(Page, typeof(Page), "ClientScript", $"alert('{errorMessage}')", true);
                    }
                }
                catch (Exception ex)
                {
                    // Log the exception and notify the user
                    ScriptManager.RegisterClientScriptBlock(Page, typeof(Page), "ClientScript", "alert('Something went wrong while sending SMS.')", true);
                    Library.writeMessageLog($"Page:Default, Method:SendSMS - {ex}");
                }
            }

            return ""; // Return an empty string as per the original method's behavior
        }

        protected void clear()
        {
            Session["contactno"] = "";
            txtcontact.Text = "";
            txtName.Text = "";
            txtjobnumber.Text = "";
            txtNote.Text = "";
            ddlstatus.SelectedValue = "Received";
            ddlqty.Text = "1";
            rbjewellery.Checked = true;
            rbdrop.Checked = true;
            HF1.Value = "";
            HFJOB.Value = "";
            HFSTATUS.Value = "";
            GridView1.DataSource = null;
            GridView1.DataBind();
            this.BindGrid();
        }
        protected void ImageButton1_Click(object sender, System.Web.UI.ImageClickEventArgs e)
        {
            Search();
        }
        protected void Search()
        {
            DataAccess DA = new DataAccess();
            DataSet dscontact = new DataSet();
            DataSet dsjob = new DataSet();
            string repairtype = "", type = "";
            if (txtcontact.Text.Trim() == "")
            {
                //MessageBox.Show("Please enter contact number");
                ScriptManager.RegisterClientScriptBlock(Page, typeof(Page), "ClientScript", "alert('Please enter contact number.')", true);
                return;
            }
            HF1.Value = "";
            try
            {
                dscontact = DA.getcontactdata(txtcode.Text.Trim() + txtcontact.Text.Trim());
                if (dscontact != null && dscontact.Tables.Count > 0)
                {
                    if (dscontact.Tables[0].Rows.Count > 0)
                    {

                        HF1.Value = dscontact.Tables[0].Rows[0][0].ToString();
                        txtName.Text = dscontact.Tables[0].Rows[0][2].ToString();
                    }
                    else
                    {
                        //MessageBox.Show("No recod found");
                        ScriptManager.RegisterClientScriptBlock(Page, typeof(Page), "ClientScript", "alert('Please enter contact number.')", true);
                        return;
                    }
                }
                else
                {
                    ScriptManager.RegisterClientScriptBlock(Page, typeof(Page), "ClientScript", "alert('No recod found.')", true);
                }
                HFJOB.Value = "";
                dsjob = DA.getJobdata(Convert.ToInt32(HF1.Value == "" ? "0" : HF1.Value));
                if (dsjob != null && dsjob.Tables.Count > 0)
                {
                    if (dsjob.Tables[0].Rows.Count > 0)
                    {
                        HFJOB.Value = dsjob.Tables[0].Rows[0][0].ToString();
                        txtjobnumber.Text = dsjob.Tables[0].Rows[0][2].ToString();
                        txtNote.Text = dsjob.Tables[0].Rows[0][3].ToString();
                        ddlstatus.SelectedValue = dsjob.Tables[0].Rows[0][4].ToString();
                        repairtype = Convert.ToString(dsjob.Tables[0].Rows[0][8]) == "" ? "Jewelry" : dsjob.Tables[0].Rows[0][8].ToString();
                        type = Convert.ToString(dsjob.Tables[0].Rows[0][9]) == "" ? "Drop" : dsjob.Tables[0].Rows[0][9].ToString();
                        ddlqty.Text = Convert.ToString(dsjob.Tables[0].Rows[0][10]) == "" ? "1" : dsjob.Tables[0].Rows[0][10].ToString();

                        if (repairtype == "Jewelry")
                            rbjewellery.Checked = true;
                        else
                            rbwatch.Checked = true;

                        if (type == "Drop")
                            rbdrop.Checked = true;
                        else
                            rbwait.Checked = true;

                        if (dsjob.Tables[1].Rows.Count > 0)
                        {
                            GridView1.DataSource = dsjob.Tables[1];
                            GridView1.DataBind();
                        }
                        else
                        {
                            GridView1.DataSource = null;
                            GridView1.DataBind();
                        }
                    }
                    else if (dsjob.Tables[1].Rows.Count > 0)
                    {
                        GridView1.DataSource = dsjob.Tables[1];
                        GridView1.DataBind();
                    }
                    else
                    {
                        GridView1.DataSource = null;
                        GridView1.DataBind();
                        //ScriptManager.RegisterClientScriptBlock(Page, typeof(Page), "ClientScript", "alert('No recod found.')", true);
                    }
                }
            }
            catch (Exception ex)
            {
                Library.writeMessageLog("Page:Default,Method:Search " + ex.ToString());
            }

        }

        protected void SearchbyJob(string jobid)
        {
            DataAccess DA = new DataAccess();
            DataSet dscontact = new DataSet();
            DataSet dsjob = new DataSet();
            string repairtype = "", type = "";
            if (txtcontact.Text.Trim() == "")
            {
                //MessageBox.Show("Please enter contact number");
                ScriptManager.RegisterClientScriptBlock(Page, typeof(Page), "ClientScript", "alert('Please enter contact number.')", true);
                return;
            }
            HF1.Value = "";
            try
            {
                dscontact = DA.getcontactdata(txtcode.Text.Trim() + txtcontact.Text.Trim());
                if (dscontact != null && dscontact.Tables.Count > 0)
                {
                    if (dscontact.Tables[0].Rows.Count > 0)
                    {

                        HF1.Value = dscontact.Tables[0].Rows[0][0].ToString();
                        txtName.Text = dscontact.Tables[0].Rows[0][2].ToString();
                    }
                    else
                    {
                        //MessageBox.Show("No recod found");
                        ScriptManager.RegisterClientScriptBlock(Page, typeof(Page), "ClientScript", "alert('Please enter contact number.')", true);
                        return;
                    }
                }
                else
                {
                    ScriptManager.RegisterClientScriptBlock(Page, typeof(Page), "ClientScript", "alert('No recod found.')", true);
                }
                HFJOB.Value = "";
                dsjob = DA.getJobdatabyContact(Convert.ToInt32(HF1.Value == "" ? "0" : HF1.Value), Convert.ToInt32(jobid == "" ? "0" : jobid));
                if (dsjob != null && dsjob.Tables.Count > 0)
                {
                    if (dsjob.Tables[0].Rows.Count > 0)
                    {
                        HFJOB.Value = dsjob.Tables[0].Rows[0][0].ToString();
                        txtjobnumber.Text = dsjob.Tables[0].Rows[0][2].ToString();
                        txtNote.Text = dsjob.Tables[0].Rows[0][3].ToString();
                        ddlstatus.SelectedValue = dsjob.Tables[0].Rows[0][4].ToString();
                        repairtype = Convert.ToString(dsjob.Tables[0].Rows[0][8]) == "" ? "Jewelry" : dsjob.Tables[0].Rows[0][8].ToString();
                        type = Convert.ToString(dsjob.Tables[0].Rows[0][9]) == "" ? "Drop" : dsjob.Tables[0].Rows[0][9].ToString();
                        ddlqty.Text = Convert.ToString(dsjob.Tables[0].Rows[0][10]) == "" ? "1" : dsjob.Tables[0].Rows[0][10].ToString();

                        if (repairtype == "Jewelry")
                            rbjewellery.Checked = true;
                        else
                            rbwatch.Checked = true;

                        if (type == "Drop")
                            rbdrop.Checked = true;
                        else
                            rbwait.Checked = true;

                        if (dsjob.Tables[1].Rows.Count > 0)
                        {
                            GridView1.DataSource = dsjob.Tables[1];
                            GridView1.DataBind();
                        }
                        else
                        {
                            GridView1.DataSource = null;
                            GridView1.DataBind();
                        }
                    }
                    else if (dsjob.Tables[1].Rows.Count > 0)
                    {
                        GridView1.DataSource = dsjob.Tables[1];
                        GridView1.DataBind();
                    }
                    else
                    {
                        GridView1.DataSource = null;
                        GridView1.DataBind();
                        //ScriptManager.RegisterClientScriptBlock(Page, typeof(Page), "ClientScript", "alert('No recod found.')", true);
                    }
                }
            }
            catch (Exception ex)
            {
                Library.writeMessageLog("Page:Default,Method:Search " + ex.ToString());
            }

        }

        private void BindGrid(string sortExpression = null, string searchText = null)
        {
            string query = "SELECT j.[ID],[ContactID],[JobID],[Note],[Status],[Closed],c.ContactNo,c.[Name] FROM [dbo].[JobMaster] j inner join ContactMaster c on j.ContactID=c.ID  WHERE [status] in ('Received','Exception')";
            string constr = ConfigurationManager.AppSettings["Connectionstring"];
            try
            {
                using (SqlConnection con = new SqlConnection(constr))
                {
                    using (SqlCommand cmd = new SqlCommand())
                    {
                        using (SqlDataAdapter sda = new SqlDataAdapter())
                        {
                            cmd.CommandText = query;
                            cmd.Connection = con;
                            sda.SelectCommand = cmd;
                            using (DataTable dt = new DataTable())
                            {
                                sda.Fill(dt);

                                //dt = DA.getJobdata(0);
                                if (sortExpression != null)
                                {
                                    DataView dv = dt.AsDataView();
                                    this.SortDirection = this.SortDirection == "ASC" ? "DESC" : "ASC";

                                    dv.Sort = sortExpression + " " + this.SortDirection;
                                    this.GridView1.DataSource = dv;
                                }
                                else
                                {
                                    this.GridView2.DataSource = dt;
                                }
                                this.GridView2.DataBind();
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Library.writeMessageLog("Page:Default,Method:BindGrid " + ex.ToString());
            }
        }
        protected void OnPageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            this.GridView1.PageIndex = e.NewPageIndex;
            this.BindGrid(null, "");
        }
        protected void OnSorting(object sender, GridViewSortEventArgs e)
        {
            this.BindGrid(e.SortExpression, "");
        }
        protected void GridView2_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            try
            {
                if (e.CommandName == "Select")
                {
                    //Determine the RowIndex of the Row whose LinkButton was clicked.
                    GridViewRow row = (GridViewRow)(((Control)e.CommandSource).NamingContainer);
                    int rowIndex = row.RowIndex;
                    //GridViewRow row = GridView1.Rows[rowIndex];
                    string contactno = row.Cells[1].Text;
                    string jobid = row.Cells[2].Text;
                    txtcontact.Text = contactno.Substring(1, contactno.Length - 1);
                    SearchbyJob(jobid);
                }
            }
            catch (Exception ex)
            {
                Library.writeMessageLog("Page:Default,Method:GridView1_RowCommand " + ex.ToString());
            }
        }
        protected void ddlstatus_SelectedIndexChanged(object sender, EventArgs e)
        {

            HFSTATUS.Value = ddlstatus.SelectedValue;
        }
    }


}