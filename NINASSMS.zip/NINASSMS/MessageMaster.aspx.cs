﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using static System.Runtime.CompilerServices.RuntimeHelpers;

namespace NINASSMS
{
    public partial class MessageMaster : System.Web.UI.Page
    {
        DataAccess DA = new DataAccess();
        private string SortDirection
        {
            get { return ViewState["SortDirection"] != null ? ViewState["SortDirection"].ToString() : "ASC"; }
            set { ViewState["SortDirection"] = value; }
        }
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!this.IsPostBack)
            {
                DataSet dt = new DataSet();
                dt = DA.getMessage();
                if (dt.Tables.Count > 0 && dt.Tables[0].Rows.Count > 0)
                {
                    GridView1.DataSource = dt.Tables[0];
                    GridView1.DataBind();
                    FillMEssage(dt.Tables[0]);
                }
                this.BindGrid();
            }
        }

        private void FillMEssage(DataTable dt)
        {
            DropDownList1.Items.Clear();
            DropDownList1.DataSource = dt;
            DropDownList1.DataValueField = "Status";       // value stored
            DropDownList1.DataTextField = "Status";   // text displayed

            DropDownList1.DataBind();
        }

        private void BindGrid(string sortExpression = null, string searchText = null)
        {
            string query = "SELECT [ID],[Status],[Message] FROM [dbo].[Messages]";
            string constr = ConfigurationManager.AppSettings["Connectionstring"];
            try
            {
                using (SqlConnection con = new SqlConnection(constr))
                {
                    using (SqlCommand cmd = new SqlCommand())
                    {
                        if (!string.IsNullOrEmpty(searchText))
                        {
                            query += " WHERE " + DropDownList1.SelectedValue + " LIKE @ContactName + '%'";
                            cmd.Parameters.AddWithValue("@ContactName", searchText);
                        }
                        using (SqlDataAdapter sda = new SqlDataAdapter())
                        {
                            cmd.CommandText = query;
                            cmd.Connection = con;
                            sda.SelectCommand = cmd;
                            using (DataTable dt = new DataTable())
                            {
                                sda.Fill(dt);

                                //dt = DA.getJobdata(0);
                                if (sortExpression != null)
                                {
                                    DataView dv = dt.AsDataView();
                                    this.SortDirection = this.SortDirection == "ASC" ? "DESC" : "ASC";

                                    dv.Sort = sortExpression + " " + this.SortDirection;
                                    this.GridView1.DataSource = dv;
                                }
                                else
                                {
                                    this.GridView1.DataSource = dt;
                                }
                                this.GridView1.DataBind();
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Library.writeMessageLog("Page:CustomerList,Method:BindGrid " + ex.ToString());
            }
        }
        protected void Search(object sender, EventArgs e)
        {

            this.BindGrid(null, txtSearch.Text);
        }
        protected void OnPageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            this.GridView1.PageIndex = e.NewPageIndex;
            this.BindGrid(null, txtSearch.Text);
        }
        protected void OnSorting(object sender, GridViewSortEventArgs e)
        {
            this.BindGrid(e.SortExpression, txtSearch.Text);
        }

        protected void GridView1_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            try
            {
                if (e.CommandName == "Select")
                {
                    //Determine the RowIndex of the Row whose LinkButton was clicked.
                    GridViewRow row = (GridViewRow)(((Control)e.CommandSource).NamingContainer);
                    int rowIndex = row.RowIndex;
                    //GridViewRow row = GridView1.Rows[rowIndex];
                    string Status = row.Cells[1].Text;
                    DropDownList1.SelectedValue = Status;
                    string message = row.Cells[2].Text;
                    TextMessage.Text = message;
                    Session["id"] = e.CommandArgument;
                    //Response.Redirect("Message.aspx?id=" + e.CommandArgument);
                }
            }
            catch (Exception ex)
            {
                Library.writeMessageLog("Page:CustomerList,Method:GridView1_RowCommand " + ex.ToString());
            }
        }

        protected void btnsave_Click(object sender, EventArgs e)
        {
            int result = 0;
            DataAccess DA = new DataAccess();
            try
            {
                result = DA.InsertMessage(Convert.ToString(DropDownList1.SelectedValue), TextMessage.Text.Trim());//5/2/2026: Prem Asked to same the contacts
                BindGrid();
                TextMessage.Text="";
                DropDownList1.SelectedIndex = 0;
            }
            catch (Exception ex)
            {
                Library.writeMessageLog("Page:Default,Method:btnsave_Click" + ex.ToString());
                ScriptManager.RegisterClientScriptBlock(Page, typeof(Page), "ClientScript", "alert('An error occurred while saving the Message.')", true);

            }
        }
    }
}