﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Mail;
using System.Net.Http;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Net.Sockets;
using System.Configuration;
using System.Net;
using System.Security.Policy;

namespace NINASSMS
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        public string apiKey = ConfigurationManager.AppSettings["apikey"];
        public string sender = ConfigurationManager.AppSettings["sender"];
        public string secret = ConfigurationManager.AppSettings["secret"];
        public string url = ConfigurationManager.AppSettings["url"];
        public string FromNo = ConfigurationManager.AppSettings["FromNo"];

        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected async void Button1_Click(object sender, EventArgs e)
        {
            sendSMS("9543007312","", "Hello, this is a test message from SimpleTexting API.");
            //string apiUrl = "https://api-app2.simpletexting.com/v2/api/messages";
            //string apiKey = "your_api_key"; // Replace with your API key
            //string phoneNumber = "19543007312"; // Replace with the recipient's phone number
            //string message = "Hello, this is a test message from SimpleTexting API.";

            //var smsData = new
            //{
            //    contactPhone = phoneNumber,
            //    accountPhone=FromNo,
            //    mode= "AUTO", 
            //    text = message,
            //   // subject= "Ninas Jewelry",
            //};

            //using (HttpClient client = new HttpClient())
            //{
            //    client.DefaultRequestHeaders.Add("Authorization", $"Bearer {apiKey}");
            //    StringContent content = new StringContent(JsonConvert.SerializeObject(smsData), Encoding.UTF8, "application/json");

            //    try
            //    {
            //        HttpResponseMessage response = client.PostAsync(url, content).Result;
            //        if (response.IsSuccessStatusCode)
            //        {
            //            Console.WriteLine("SMS sent successfully.");
            //        }
            //        else
            //        {
            //            string errorResponse = await response.Content.ReadAsStringAsync();
            //            Console.WriteLine($"Failed to send SMS. Error: {errorResponse}");
            //        }
            //    }
            //    catch (Exception ex)
            //    {
            //        Console.WriteLine($"Error: {ex.Message}");
            //    }

            //}

           // string apiUrl = "https://api-app2.simpletexting.com/v2/api/messages";
           //// string apiKey = "your_api_key";
           // string secretKey = secret;
           // string contactNo = "9543007312"; // Replace with the recipient's phone number
           // string msg = "Hello, this is a test message from SimpleTexting API.";

           // string result = SendSms(apiUrl, apiKey, secretKey, contactNo, msg);
           // Console.WriteLine(result);
        }
        public string sendSMS(string contactno, string src, string msg)
        {
            //string apiUrl = "https://api-app2.simpletexting.com/v2/api/messages"; // API endpoint URL
            string phoneNumber = contactno; // Recipient's phone number
            string message = HttpUtility.UrlEncode(msg); // URL-encoded message

            // Data to send in the SMS API request
            var smsData = new
            {
                contactPhone = phoneNumber, // Recipient's phone number
                accountPhone = FromNo,  // Dynamic account phone (replacing hardcoded value)
                mode = "AUTO", // Message mode
                text = message // Message content
            };

            using (HttpClient client = new HttpClient())
            {
                client.DefaultRequestHeaders.Add("Authorization", $"Bearer {apiKey}"); // Add the authorization header with the API key

                // Serialize the data into JSON
                StringContent content = new StringContent(JsonConvert.SerializeObject(smsData), Encoding.UTF8, "application/json");

                try
                {
                    // Send the POST request to the API
                    HttpResponseMessage response = client.PostAsync(url, content).Result;

                    if (response.IsSuccessStatusCode)
                    {
                        // Parse the response if needed (currently logging success)
                        string responseContent = response.Content.ReadAsStringAsync().Result;

                        // Show a success alert to the user
                        ScriptManager.RegisterClientScriptBlock(Page, typeof(Page), "ClientScript", "alert('SMS sent successfully.')", true);
                    }
                    else
                    {
                        // Handle error response
                        string errorResponse = response.Content.ReadAsStringAsync().Result;

                        // Extract error details if available
                        string errorMessage = "Failed to send SMS.";
                        if (!string.IsNullOrEmpty(errorResponse))
                        {
                            try
                            {
                                var errorData = JsonConvert.DeserializeObject<dynamic>(errorResponse);
                                errorMessage = errorData?.error?.message ?? errorMessage;
                            }
                            catch
                            {
                                // Ignore JSON parsing errors
                            }
                        }

                        // Display the error message
                        ScriptManager.RegisterClientScriptBlock(Page, typeof(Page), "ClientScript", $"alert('{errorMessage}')", true);
                    }
                }
                catch (Exception ex)
                {
                    // Log the exception and notify the user
                    ScriptManager.RegisterClientScriptBlock(Page, typeof(Page), "ClientScript", "alert('Something went wrong while sending SMS.')", true);
                    Library.writeMessageLog($"Page:Default, Method:SendSMS - {ex}");
                }
            }

            return ""; // Return an empty string as per the original method's behavior
        }

    }
}