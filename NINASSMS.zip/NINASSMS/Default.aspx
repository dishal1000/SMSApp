﻿<%@ Page Title="Home Page" Language="C#" MasterPageFile="~/Site.Master" AutoEventWireup="true" CodeBehind="Default.aspx.cs" Inherits="NINASSMS._Default" %>

<asp:Content ID="HeaderContent" runat="server" ContentPlaceHolderID="HeadContent">
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" />
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <style type="text/css">
          /* Custom CSS for additional styling */
        .form-group {
            margin-bottom: 20px;
        }

        .btn-save {
            margin-top: 20px;
        }

        /* Custom styles for GridView */
        .table-grid {
            margin-top: 20px;
        }
        /* Updated CSS for adjusting spacing */
        .lab {
            width: 100px;
            display: inline-block;
            margin-bottom: 5px;
        }

        .txt {
            height: 38px;
            font-size: 1rem;
            font-weight: 400;
            line-height: 1.5;
            color: #495057;
            background-color: #fff;
            background-clip: padding-box;
            border: 1px solid #ced4da;
            border-radius: .25rem;
            width: calc(100% - 105px);
            display: inline-block;
            vertical-align: middle;
            margin-bottom: 5px;
        }

        /* Additional margin for the Save button */
        #btnsave {
            margin-top: 10px;
        }

        /* Adjust GridView alignment and padding */
        .table {
            margin-top: 20px;
            border-collapse: collapse;
            width: 100%;
        }

        .table th,
        .table td {
            padding: 4px;
            text-align: left;
            border: 1px solid #ddd;
        }
    </style>
    <script language="javascript" type="text/javascript">
        function isNumber(evt) {
            evt = (evt) ? evt : window.event;
            var charCode = (evt.which) ? evt.which : evt.keyCode;
            if (charCode > 31 && (charCode < 48 || charCode > 57)) {
                return false;
            }
            return true;
        }

        function AllowAlphabet(e) {
            isIE = document.all ? 1 : 0
            keyEntry = !isIE ? e.which : event.keyCode;
            if (((keyEntry >= '65') && (keyEntry <= '90')) || ((keyEntry >= '97') && (keyEntry <= '122')) || (keyEntry == '46') || (keyEntry == '32') || keyEntry == '45')
                return true;
            else {
                alert('Please Enter Only Character values.');
                return false;
            }
        }
    </script>
</asp:Content>
<asp:Content ID="BodyContent" runat="server" ContentPlaceHolderID="MainContent">
    <h2>Welcome to Customer portal!
    </h2>
    <br />
    <br />
    <div class="container">
    <div class="row">
        <div class="col-md-4 col-sm-12 mt-3">
            <label class="lab" style="width:120px;">Contact number</label>
            <asp:TextBox ID="txtcode" runat="server" ReadOnly="True" Width="20px">1</asp:TextBox>
            <asp:TextBox ID="txtcontact" runat="server" ToolTip="Enter customer contact" OnTextChanged="txtcontact_TextChanged"
                MaxLength="10" onkeypress="return isNumber(event)" Width="100px"></asp:TextBox>
            <asp:ImageButton ID="ImageButton1" runat="server" Height="25px" ImageUrl="~/Search-button.png"
                OnClick="ImageButton1_Click" Width="25px" />
        </div>
        <div class="col-md-4 col-sm-12 mt-3">
            <label class="lab">Name</label>
            <asp:TextBox ID="txtName" runat="server" ToolTip="Enter customer name" MaxLength="30"
                onkeypress="return AllowAlphabet(event)"></asp:TextBox>

        </div>
        <div class="col-md-4 mt-3">
        </div>

        <div class="col-md-4 col-sm-12 mt-3">
            <label class="lab" style="width:120px;">Job number</label>
            <asp:TextBox ID="txtjobnumber" runat="server" ToolTip="Enter job name" MaxLength="20"></asp:TextBox>
        </div>
        <div class="col-md-4 col-sm-12 mt-3">
            <label class="lab">Repair type</label>
            <asp:RadioButton ID="rbjewellery" GroupName="repairtype" Checked="true" Text="Jewelry" runat="server" />
            <asp:RadioButton ID="rbwatch" GroupName="repairtype" Text="Watch" runat="server" />
        </div>

        <div class="col-md-4 mt-3">
            <label class="lab" style="visibility:hidden;">Type</label>
        </div>

        <div class="col-md-4 col-sm-12 mt-3">
            <label class="lab" style="width:120px;">Qty</label>
            <%--<asp:DropDownList ID="ddlqty" runat="server">
                <asp:ListItem>1</asp:ListItem>
                <asp:ListItem>2</asp:ListItem>
                <asp:ListItem>3</asp:ListItem>
                <asp:ListItem>4</asp:ListItem>
                <asp:ListItem>5</asp:ListItem>
                <asp:ListItem>6</asp:ListItem>
                <asp:ListItem>7</asp:ListItem>
                <asp:ListItem>8</asp:ListItem>
                <asp:ListItem>9</asp:ListItem>
                <asp:ListItem>10</asp:ListItem>
                <asp:ListItem>11</asp:ListItem>
                <asp:ListItem>12</asp:ListItem>
                <asp:ListItem>13</asp:ListItem>
                <asp:ListItem>14</asp:ListItem>
                <asp:ListItem>15</asp:ListItem>
                <asp:ListItem>16</asp:ListItem>
                <asp:ListItem>17</asp:ListItem>
                <asp:ListItem>18</asp:ListItem>
                <asp:ListItem>19</asp:ListItem>
                <asp:ListItem>20</asp:ListItem>
            </asp:DropDownList>--%>
            <asp:TextBox ID="ddlqty" runat="server"></asp:TextBox>
        </div>
        <div class="col-md-4 col-sm-12 mt-3">
            
             <label class="lab">Status</label>
 <asp:DropDownList ID="ddlstatus" runat="server" AutoPostBack="true"
                OnSelectedIndexChanged="ddlstatus_SelectedIndexChanged">
     <%--<asp:ListItem Text="Received" Value="Received"></asp:ListItem>
                     <asp:ListItem Text="Completed" Value="Completed"></asp:ListItem>
                     <asp:ListItem Text="Exception" Value="Exception"></asp:ListItem>
                     <asp:ListItem Text="Marketing" Value="Marketing"></asp:ListItem>--%>
 </asp:DropDownList>
            

        </div>

        <div class="col-md-4 mt-3">
            <asp:RadioButton ID="rbdrop" GroupName="type" Text="Drop" Checked="true" runat="server"  style="visibility:hidden;"/>
<asp:RadioButton ID="rbwait" GroupName="type" Text="Wait" runat="server"  style="visibility:hidden;"/>
        </div>


        <div class="col-md-4 col-sm-12 mt-3">
            <label class="lab" style="width:120px;">Note</label>
            <asp:TextBox ID="txtNote" runat="server" ToolTip="Enter job name" Height="56px" MaxLength="200"
                TextMode="MultiLine" Width="203px"></asp:TextBox>
        </div>
        <div class="col-md-4 col-sm-12 mt-3">
            <%--<label class="lab">Status</label>--%>
            <%--<asp:DropDownList ID="ddlstatus" runat="server" AutoPostBack="true"
                OnSelectedIndexChanged="ddlstatus_SelectedIndexChanged">
                
            </asp:DropDownList>--%>
            <%--<asp:ListItem Text="Received" Value="Received"></asp:ListItem>
                <asp:ListItem Text="Completed" Value="Completed"></asp:ListItem>
                <asp:ListItem Text="Exception" Value="Exception"></asp:ListItem>
                <asp:ListItem Text="Marketing" Value="Marketing"></asp:ListItem>--%>
            <asp:Button ID="btnsave" runat="server" CssClass="btn btn-primary" Text="Save" OnClick="btnsave_Click" />
<asp:HiddenField ID="HF1" runat="server" />
<asp:HiddenField ID="HFJOB" runat="server" />
<asp:HiddenField ID="HFSTATUS" runat="server" />
        </div>
        <div class="col-md-4 mt-3">
        </div>
       <%-- <div class="col-md-4 col-sm-12 mt-3">
            
        </div>--%>
    </div>
        </div>  
    <%--<br />
    <br />--%>
    <div class="container">
    <div class="row">
        <div class="col-md-8 col-sm-12">
            <asp:GridView ID="GridView2" runat="server" CssClass="table table-responsive-sm table-striped table-hover table-bordered" AutoGenerateColumns="false" AllowPaging="true"
                AllowSorting="true" OnSorting="OnSorting" OnPageIndexChanging="OnPageIndexChanging"
                PageSize="15" OnRowCommand="GridView2_RowCommand">
                <Columns>
                    <%--<asp:TemplateField>
                                        <ItemTemplate>
                                            <asp:CheckBox ID="chkRow" runat="server" />
                                        </ItemTemplate>
                                    </asp:TemplateField>--%>
                    <asp:BoundField DataField="Name" HeaderText="Name" ItemStyle-Width="150" SortExpression="Name" />
                    <asp:BoundField DataField="ContactNo" HeaderText="Contact number" ItemStyle-Width="150"
                        SortExpression="ContactNo" />
                    <asp:BoundField DataField="JobID" HeaderText="Job number" ItemStyle-Width="150" SortExpression="JobID" />
                    <asp:BoundField DataField="Status" HeaderText="Status" ItemStyle-Width="150" SortExpression="Status" />
                    <asp:BoundField DataField="Note" HeaderText="Note" ItemStyle-Width="150" SortExpression="Note" />
                    <asp:TemplateField>
                        <ItemTemplate>
                            <asp:LinkButton ID="LinkButton1" Text="Select" runat="server" CommandName="Select"
                                CommandArgument='<%# Eval("Id") %>' />
                        </ItemTemplate>
                    </asp:TemplateField>
                </Columns>
            </asp:GridView>
        </div>
    </div>


    <table>
        <tr>
            <td class="style1"></td>
            <td>
                <asp:GridView ID="GridView1" runat="server" >
                </asp:GridView>
            </td>
        </tr>
    </table>
    </div>
</asp:Content>
