﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Newtonsoft.Json;
using System.Net.Http;
using System.Text;

namespace NINASSMS
{
    public partial class JobMaster : System.Web.UI.Page
    {
        public string apikey = ConfigurationManager.AppSettings["apikey"];
        public string sender = ConfigurationManager.AppSettings["sender"];
        public string secret = ConfigurationManager.AppSettings["secret"];
        public string url = ConfigurationManager.AppSettings["url"];
        public string FromNo = ConfigurationManager.AppSettings["FromNo"];
        DataAccess DA = new DataAccess();
        private string SortDirection
        {
            get { return ViewState["SortDirection"] != null ? ViewState["SortDirection"].ToString() : "ASC"; }
            set { ViewState["SortDirection"] = value; }
        }
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!this.IsPostBack)
            {
                DataSet dt = new DataSet();
                dt = DA.getJobdata(0);
                if (dt.Tables.Count > 0 && dt.Tables[0].Rows.Count > 0)
                {
                    GridView1.DataSource = dt.Tables[0];
                    GridView1.DataBind();

                }
                this.BindGrid();
            }
        }

        private void BindGrid(string sortExpression = null, string searchText = null)
        {
            string query = "SELECT j.[ID],[ContactID],[JobID],[Note],[Status],[Closed],c.ContactNo,c.[Name] FROM [dbo].[JobMaster] j inner join ContactMaster c on j.ContactID=c.ID";
            string constr = ConfigurationManager.AppSettings["Connectionstring"];
            try
            {
                using (SqlConnection con = new SqlConnection(constr))
                {
                    using (SqlCommand cmd = new SqlCommand())
                    {
                        if (!string.IsNullOrEmpty(searchText))
                        {
                            if (DropDownList1.SelectedValue == "Status" && searchText == "Completed")
                            {
                                query += " WHERE " + DropDownList1.SelectedValue + " in ('Pickup','Completed')";
                                //cmd.Parameters.AddWithValue("@ContactName", searchText);
                            }
                            else
                            {
                                query += " WHERE " + DropDownList1.SelectedValue + " LIKE @ContactName + '%'";
                                cmd.Parameters.AddWithValue("@ContactName", searchText);
                            }
                        }
                        else
                        {
                            query += " WHERE [status] in ('Received','Exception')";
                            //cmd.Parameters.AddWithValue("@ContactName", searchText);
                        }
                        using (SqlDataAdapter sda = new SqlDataAdapter())
                        {
                            cmd.CommandText = query;
                            cmd.Connection = con;
                            sda.SelectCommand = cmd;
                            using (DataTable dt = new DataTable())
                            {
                                sda.Fill(dt);

                                //dt = DA.getJobdata(0);
                                if (sortExpression != null)
                                {
                                    DataView dv = dt.AsDataView();
                                    this.SortDirection = this.SortDirection == "ASC" ? "DESC" : "ASC";

                                    dv.Sort = sortExpression + " " + this.SortDirection;
                                    this.GridView1.DataSource = dv;
                                }
                                else
                                {
                                    this.GridView1.DataSource = dt;
                                }
                                this.GridView1.DataBind();
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Library.writeMessageLog("Page:JobMaster,Method:BindGrid " + ex.ToString());
            }
        }
        protected void Search(object sender, EventArgs e)
        {
            this.BindGrid(null, txtSearch.Text);
        }
        protected void OnPageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            this.GridView1.PageIndex = e.NewPageIndex;
            this.BindGrid(null, txtSearch.Text);
        }
        protected void OnSorting(object sender, GridViewSortEventArgs e)
        {
            this.BindGrid(e.SortExpression, txtSearch.Text);
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            DataSet ds = new DataSet();
            ds = DA.getMessageList();
            if (ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
            {

            }

            foreach (GridViewRow row in GridView1.Rows)
            {
                if (row.RowType == DataControlRowType.DataRow)
                {
                    CheckBox chkRow = (row.Cells[0].FindControl("chkRow") as CheckBox);
                    if (chkRow.Checked)
                    {
                        string name = row.Cells[1].Text;
                        string contactNo = row.Cells[2].Text;
                        SendSMS(name, contactNo, txtmsg.Text.Trim());
                    }
                }
            }
        }

        //private void SendSMS(string name, string contactNo, string msg)
        //{
        //    String message = HttpUtility.UrlEncode(msg);

        //    using (var wb = new WebClient())
        //    {
        //        string key = apikey;
        //        string secretkey = secret;
        //        string URL = url;
        //        string to = contactNo;
        //        string messages = msg;

        //        string sURL;


        //        sURL = URL + key + "&api_secret=" + secretkey + "&to=" + to + "&text=" + messages;

        //        try
        //        {

        //            using (WebClient client = new WebClient())
        //            {
        //                client.Encoding = System.Text.Encoding.UTF8;

        //                var s = client.DownloadString(sURL);
        //                string ErrorMessage = "";
        //                int status = 0;
        //                string[] resp = s.Split(',');
        //                if (resp.Length > 0)
        //                {
        //                    if (resp[3].ToString() != "")
        //                    {
        //                        //resp[3]=resp[3].Replace(":","");
        //                        string[] errormsg = resp[3].Split(':');
        //                        if (errormsg.Length > 0)
        //                        {
        //                            ErrorMessage = errormsg[1].ToString();
        //                        }
        //                    }
        //                    if (resp[4].ToString() != "")
        //                    {
        //                        resp[3] = resp[4].Replace(":", "");
        //                        string[] Statusmsg = resp[4].Split(':');
        //                        if (Statusmsg.Length > 0)
        //                        {
        //                            status = Convert.ToInt32(Statusmsg[1].ToString().Replace("}", ""));
        //                        }
        //                    }
        //                }
        //                if (status != 0)
        //                {
        //                    ScriptManager.RegisterClientScriptBlock(Page, typeof(Page), "ClientScript", "alert(" + ErrorMessage + ")", true);
        //                }

        //            }


        //        }
        //        catch (Exception ex)
        //        {
        //            ScriptManager.RegisterClientScriptBlock(Page, typeof(Page), "ClientScript", "alert('Something went wrong while sending sms.')", true);
        //            Library.writeMessageLog("Page:JobMaster,Method:SendSMS " + ex.ToString());
        //        }
        //    }
        //}
        public string SendSMS(string src, string contactno,  string msg)
        {
            //string apiUrl = "https://api-app2.simpletexting.com/v2/api/messages"; // API endpoint URL
            string phoneNumber = contactno; // Recipient's phone number
            string message = HttpUtility.UrlEncode(msg).Replace("+", " ").Replace("%3a", ":").Replace("%3f", "?").Replace("%27", "'").Replace("%2f", "/").Replace("%2c", ","); // URL-encoded message

            // Data to send in the SMS API request
            var smsData = new
            {
                contactPhone = phoneNumber, // Recipient's phone number
                accountPhone = FromNo,  // Dynamic account phone (replacing hardcoded value)
                mode = "AUTO", // Message mode
                text = message // Message content
            };

            using (HttpClient client = new HttpClient())
            {
                client.DefaultRequestHeaders.Add("Authorization", $"Bearer {apikey}"); // Add the authorization header with the API key

                // Serialize the data into JSON
                StringContent content = new StringContent(JsonConvert.SerializeObject(smsData), Encoding.UTF8, "application/json");

                try
                {
                    // Send the POST request to the API
                    HttpResponseMessage response = client.PostAsync(url, content).Result;

                    if (response.IsSuccessStatusCode)
                    {
                        // Parse the response if needed (currently logging success)
                        string responseContent = response.Content.ReadAsStringAsync().Result;

                        // Show a success alert to the user
                        ScriptManager.RegisterClientScriptBlock(Page, typeof(Page), "ClientScript", "alert('SMS sent successfully.')", true);
                    }
                    else
                    {
                        // Handle error response
                        string errorResponse = response.Content.ReadAsStringAsync().Result;

                        // Extract error details if available
                        string errorMessage = "Failed to send SMS.";
                        if (!string.IsNullOrEmpty(errorResponse))
                        {
                            try
                            {
                                var errorData = JsonConvert.DeserializeObject<dynamic>(errorResponse);
                                errorMessage = errorData?.error?.message ?? errorMessage;
                            }
                            catch
                            {
                                // Ignore JSON parsing errors
                            }
                        }

                        // Display the error message
                        ScriptManager.RegisterClientScriptBlock(Page, typeof(Page), "ClientScript", $"alert('{errorMessage}')", true);
                    }
                }
                catch (Exception ex)
                {
                    // Log the exception and notify the user
                    ScriptManager.RegisterClientScriptBlock(Page, typeof(Page), "ClientScript", "alert('Something went wrong while sending SMS.')", true);
                    Library.writeMessageLog($"Page:Default, Method:SendSMS - {ex}");
                }
            }

            return ""; // Return an empty string as per the original method's behavior
        }

        protected void GridView1_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            try
            {
                if (e.CommandName == "Select")
                {
                    //Determine the RowIndex of the Row whose LinkButton was clicked.
                    GridViewRow row = (GridViewRow)(((Control)e.CommandSource).NamingContainer);
                    int rowIndex = row.RowIndex;
                    //GridViewRow row = GridView1.Rows[rowIndex];
                    string contactno = row.Cells[2].Text;
                    string jobid = row.Cells[3].Text;
                    Session["contactno"] = contactno;
                    Session["jobid"] = jobid;
                    Response.Redirect("Default.aspx?id=" + e.CommandArgument);
                }
            }
            catch (Exception ex)
            {
                Library.writeMessageLog("Page:JobMaster,Method:GridView1_RowCommand " + ex.ToString());
            }
        }
    }
}