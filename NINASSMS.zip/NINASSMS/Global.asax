﻿<%@ Application Codebehind="Global.asax.cs" Inherits="NINASSMS.Global" Language="C#" %>
