﻿<%@ Page Title="" Language="C#" MasterPageFile="~/Site.Master" AutoEventWireup="true" CodeBehind="CompleteStatus.aspx.cs" Inherits="NINASSMS.CompleteStatus" %>

<asp:Content ID="Content1" ContentPlaceHolderID="HeadContent" runat="server">
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />

    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" />
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

    <script language="javascript" type="text/javascript">
        function isNumber(evt) {
            evt = (evt) ? evt : window.event;
            var charCode = (evt.which) ? evt.which : evt.keyCode;
            if (charCode > 31 && (charCode < 48 || charCode > 57)) {
                return false;
            }
            return true;
        }
    </script>

</asp:Content>
<asp:Content ID="Content2" ContentPlaceHolderID="MainContent" runat="server">
    <div class="jumbotron">
        <div class="container">
            <!-- Page Header -->
            <h2 class="text-center font-weight-bold text-primary">Direct Message</h2>
            <hr />

            <div class="row">

                <!-- LEFT SIDE (Form) -->
                <div class="col-md-8">
                    <div class="row">
                        <div class="col col-12 col-md-6 mt-3">
                            <label class="lab">Contact number</label>
                            <asp:TextBox ID="txtcode" runat="server" CssClass="txt" ReadOnly="True" Width="5%">1</asp:TextBox>
                            <asp:TextBox ID="txtcontact" runat="server" CssClass="txt" ToolTip="Enter customer contact"
                                MaxLength="10" onkeypress="return isNumber(event)" Width="30%"></asp:TextBox>
                            <asp:Button ID="btnsave" runat="server" CssClass="btn btn-primary" Text="Review Request" OnClick="btnsave_Click" />
                        </div>
                        <div class="col-md-4 col-sm-12 mt-3">
                        </div>
                    </div>
                </div>

                <!-- RIGHT SIDE (Message Panel) -->
                <div class="col-md-4">
                    <div class="alert alert-info"
                        style="min-height: 300px; max-height: 400px; overflow-y: auto; white-space: pre-line;">

                        <asp:Label
                            ID="lblMessage"
                            runat="server"
                            Text=""
                            CssClass="d-block">
                        </asp:Label>

                    </div>
                </div>
            </div>
    </div>
</asp:Content>

