﻿<%@ Page Title="" Language="C#" MasterPageFile="~/Site.Master" AutoEventWireup="true" CodeBehind="MessageMaster.aspx.cs" Inherits="NINASSMS.MessageMaster" %>

<asp:Content ID="Content1" ContentPlaceHolderID="HeadContent" runat="Server">
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" />
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</asp:Content>
<asp:Content ID="Content2" ContentPlaceHolderID="MainContent" runat="Server" ValidateRequest="false">
    <div class="jumbotron">
        <!-- Page Header -->
        <h2 class="text-center font-weight-bold text-primary">Message Master</h2>
        <hr />
        <div>
            <div class="row pb-4">
                <div class="col-md-3 col-sm-12 pl-0 pt-2">
                    <asp:DropDownList ID="DropDownList1" CssClass="form-control" runat="server">
                        <asp:ListItem Text="Name" Value="Name" Selected="True" />
                        <asp:ListItem Text="Contact number" Value="ContactNo" />
                    </asp:DropDownList>
                </div>
                <div class="col-md-3 col-sm-12 pl-0 pt-2">
                    <div class="row">
                        <div class="col-md-9 col-sm-10 col-10 pr-1">
                            <asp:TextBox ID="txtSearch" CssClass="form-control" runat="server" Visible="false"></asp:TextBox>
                            <asp:TextBox ID="TextMessage" CssClass="form-control" runat="server" TextMode="MultiLine" MaxLength="150"></asp:TextBox>
                        </div>
                        <div class="col-md-3 col-sm-2 col-2 pl-0 pt-1">

                            <%--<asp:Button ID="btnSearch" runat="server" OnClick="Search" CssClass="btn btn-sm btn-primary" Text="Search" />--%>
                            <asp:Button ID="btnsave" runat="server" Text="Save" OnClick="btnsave_Click" CssClass="btn btn-sm btn-primary" />
                        </div>
                    </div>
                </div>
                <div class="col-md-6 col-sm-12 pl-0 pt-2">
                </div>
            </div>
            <div class="row">
                <div class="col-md-6 col-sm-12">
                    <asp:GridView ID="GridView1" runat="server"
                        CssClass="table table-striped table-hover table-bordered"
                        AutoGenerateColumns="false"
                        AllowPaging="true"
                        AllowSorting="true"
                        OnSorting="OnSorting"
                        OnPageIndexChanging="OnPageIndexChanging"
                        OnRowCommand="GridView1_RowCommand"
                        PageSize="30">

                        <Columns>

                            <asp:TemplateField HeaderText="" ItemStyle-Width="70px">
                                <HeaderStyle Width="70px" />
                                <ItemStyle Width="70px" />

                                <ItemTemplate>
                                    <asp:LinkButton ID="LinkButton1"
                                        runat="server"
                                        Text="Select"
                                        CommandName="Select"
                                        CommandArgument='<%# Eval("Id") %>' />
                                </ItemTemplate>
                            </asp:TemplateField>

                            <asp:BoundField DataField="Status"
                                HeaderText="Status"
                                SortExpression="Status">
                                <HeaderStyle Width="150px" />
                                <ItemStyle Width="150px" />
                            </asp:BoundField>

                            <asp:BoundField DataField="Message"
                                HeaderText="Message"
                                SortExpression="Message">
                                <HeaderStyle Width="500px" />
                                <ItemStyle Width="500px" />
                            </asp:BoundField>

                        </Columns>
                    </asp:GridView>
                </div>
            </div>
            <br />
        </div>
    </div>
</asp:Content>


